import React, { useState, useEffect } from 'react';
import { FileText, Upload, Search, Filter, Grid, List, User, Settings, Moon, Sun } from 'lucide-react';
import DocumentCard from './components/DocumentCard';
import UploadArea from './components/UploadArea';
import SearchBar from './components/SearchBar';
import Navigation from './components/Navigation';
import UserProfile from './components/UserProfile';

interface Document {
  id: string;
  title: string;
  description: string;
  type: string;
  size: string;
  uploadDate: string;
  thumbnail: string;
  downloadCount: number;
  tags: string[];
}

function App() {
  const [documents, setDocuments] = useState<Document[]>([
    {
      id: '1',
      title: 'Project Proposal 2025',
      description: 'Comprehensive project proposal for Q1 2025 initiatives',
      type: 'PDF',
      size: '2.4 MB',
      uploadDate: '2024-12-15',
      thumbnail: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg',
      downloadCount: 47,
      tags: ['proposal', 'project', '2025']
    },
    {
      id: '2',
      title: 'Design System Guidelines',
      description: 'Complete design system documentation and component library',
      type: 'FIGMA',
      size: '5.7 MB',
      uploadDate: '2024-12-14',
      thumbnail: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg',
      downloadCount: 128,
      tags: ['design', 'ui', 'guidelines']
    },
    {
      id: '3',
      title: 'Financial Report Q4',
      description: 'Quarterly financial analysis and performance metrics',
      type: 'XLSX',
      size: '1.8 MB',
      uploadDate: '2024-12-13',
      thumbnail: 'https://images.pexels.com/photos/590020/pexels-photo-590020.jpeg',
      downloadCount: 73,
      tags: ['finance', 'report', 'q4']
    },
    {
      id: '4',
      title: 'Team Meeting Recording',
      description: 'Weekly team sync and project updates discussion',
      type: 'MP4',
      size: '89.2 MB',
      uploadDate: '2024-12-12',
      thumbnail: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg',
      downloadCount: 31,
      tags: ['meeting', 'team', 'video']
    }
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         doc.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         doc.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'all' || 
                           doc.type.toLowerCase() === selectedCategory.toLowerCase();
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className={`min-h-screen transition-all duration-500 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900' 
        : 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50'
    }`}>
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-r from-yellow-400 to-red-400 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-blob animation-delay-2000"></div>
        <div className="absolute top-40 left-40 w-80 h-80 bg-gradient-to-r from-green-400 to-blue-400 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-blob animation-delay-4000"></div>
      </div>

      <Navigation 
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
      />

      <main className="relative z-10 container mx-auto px-6 py-8">
        {/* Header Section */}
        <header className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mb-6 animate-float">
            <FileText className="w-10 h-10 text-white" />
          </div>
          <h1 className={`text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent animate-shimmer`}>
            Document Management System
          </h1>
          <p className={`text-xl ${isDarkMode ? 'text-gray-300' : 'text-gray-600'} max-w-2xl mx-auto`}>
            Organize, search, and manage your documents with advanced 3D animations and intelligent categorization
          </p>
        </header>

        {/* Search and Controls */}
        <div className="mb-8 space-y-6">
          <SearchBar 
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            isDarkMode={isDarkMode}
          />
          
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-3 rounded-xl transition-all duration-300 transform hover:scale-105 ${
                  viewMode === 'grid'
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                    : isDarkMode ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' : 'bg-white text-gray-600 hover:bg-gray-50'
                }`}
              >
                <Grid className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-3 rounded-xl transition-all duration-300 transform hover:scale-105 ${
                  viewMode === 'list'
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                    : isDarkMode ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' : 'bg-white text-gray-600 hover:bg-gray-50'
                }`}
              >
                <List className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center space-x-2">
              <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                {filteredDocuments.length} documents found
              </span>
            </div>
          </div>
        </div>

        {/* Upload Area */}
        <UploadArea isDarkMode={isDarkMode} />

        {/* Documents Grid/List */}
        <div className={`grid gap-6 ${
          viewMode === 'grid' 
            ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
            : 'grid-cols-1'
        }`}>
          {filteredDocuments.map((document, index) => (
            <DocumentCard
              key={document.id}
              document={document}
              viewMode={viewMode}
              isDarkMode={isDarkMode}
              index={index}
            />
          ))}
        </div>

        {filteredDocuments.length === 0 && (
          <div className="text-center py-16">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-gray-400 to-gray-500 rounded-full mb-4">
              <Search className="w-8 h-8 text-white" />
            </div>
            <p className={`text-xl ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
              No documents found matching your search criteria
            </p>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;