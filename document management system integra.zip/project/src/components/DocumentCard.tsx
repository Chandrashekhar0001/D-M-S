import React, { useState } from 'react';
import { Download, Eye, MoreVertical, Tag, Calendar, FileText, Image, Video, Music, Archive } from 'lucide-react';

interface Document {
  id: string;
  title: string;
  description: string;
  type: string;
  size: string;
  uploadDate: string;
  thumbnail: string;
  downloadCount: number;
  tags: string[];
}

interface DocumentCardProps {
  document: Document;
  viewMode: 'grid' | 'list';
  isDarkMode: boolean;
  index: number;
}

const getFileIcon = (type: string) => {
  switch (type.toLowerCase()) {
    case 'pdf':
    case 'doc':
    case 'docx':
      return FileText;
    case 'jpg':
    case 'jpeg':
    case 'png':
    case 'gif':
    case 'figma':
      return Image;
    case 'mp4':
    case 'avi':
    case 'mov':
      return Video;
    case 'mp3':
    case 'wav':
      return Music;
    default:
      return Archive;
  }
};

const getTypeColor = (type: string) => {
  switch (type.toLowerCase()) {
    case 'pdf':
      return 'from-red-500 to-red-600';
    case 'doc':
    case 'docx':
      return 'from-blue-500 to-blue-600';
    case 'xlsx':
      return 'from-green-500 to-green-600';
    case 'jpg':
    case 'jpeg':
    case 'png':
    case 'gif':
      return 'from-purple-500 to-purple-600';
    case 'figma':
      return 'from-pink-500 to-pink-600';
    case 'mp4':
    case 'avi':
    case 'mov':
      return 'from-orange-500 to-orange-600';
    case 'mp3':
    case 'wav':
      return 'from-teal-500 to-teal-600';
    default:
      return 'from-gray-500 to-gray-600';
  }
};

const DocumentCard: React.FC<DocumentCardProps> = ({ document, viewMode, isDarkMode, index }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isFlipped, setIsFlipped] = useState(false);
  const FileIcon = getFileIcon(document.type);
  const typeColor = getTypeColor(document.type);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (viewMode === 'list') {
    return (
      <div 
        className={`group relative overflow-hidden rounded-2xl backdrop-blur-md border transition-all duration-500 transform hover:scale-[1.02] hover:shadow-2xl ${
          isDarkMode 
            ? 'bg-gray-800/50 border-gray-700/50 hover:bg-gray-800/70' 
            : 'bg-white/80 border-white/20 hover:bg-white/90'
        }`}
        style={{ animationDelay: `${index * 100}ms` }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="flex items-center p-6 space-x-6">
          <div className={`relative w-16 h-16 rounded-xl bg-gradient-to-br ${typeColor} flex items-center justify-center transform transition-all duration-300 ${
            isHovered ? 'rotate-12 scale-110' : ''
          }`}>
            <FileIcon className="w-8 h-8 text-white" />
          </div>
          
          <div className="flex-1 min-w-0">
            <h3 className={`text-lg font-semibold truncate ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {document.title}
            </h3>
            <p className={`text-sm truncate ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {document.description}
            </p>
            <div className="flex items-center space-x-4 mt-2">
              <span className={`text-xs px-2 py-1 rounded-full bg-gradient-to-r ${typeColor} text-white`}>
                {document.type}
              </span>
              <span className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                {document.size}
              </span>
              <span className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                {formatDate(document.uploadDate)}
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <button className={`p-3 rounded-xl transition-all duration-300 transform hover:scale-110 bg-gradient-to-r from-blue-500 to-purple-500 text-white hover:shadow-lg`}>
              <Eye className="w-5 h-5" />
            </button>
            <button className={`p-3 rounded-xl transition-all duration-300 transform hover:scale-110 bg-gradient-to-r from-green-500 to-teal-500 text-white hover:shadow-lg`}>
              <Download className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="group perspective-1000"
      style={{ animationDelay: `${index * 100}ms` }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div 
        className={`relative preserve-3d transition-all duration-700 transform ${
          isFlipped ? 'rotate-y-180' : ''
        } ${
          isHovered ? 'scale-105 -translate-y-2' : ''
        }`}
        onClick={() => setIsFlipped(!isFlipped)}
      >
        {/* Front Face */}
        <div className={`backface-hidden relative overflow-hidden rounded-3xl backdrop-blur-md border transition-all duration-500 ${
          isDarkMode 
            ? 'bg-gray-800/60 border-gray-700/50' 
            : 'bg-white/80 border-white/30'
        } shadow-xl hover:shadow-2xl`}>
          <div className="relative h-48 overflow-hidden rounded-t-3xl">
            <img 
              src={document.thumbnail} 
              alt={document.title}
              className={`w-full h-full object-cover transition-all duration-700 transform ${
                isHovered ? 'scale-110 rotate-2' : ''
              }`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${typeColor} text-white backdrop-blur-sm`}>
              {document.type}
            </div>
            <div className="absolute bottom-4 left-4 right-4">
              <div className="flex flex-wrap gap-1">
                {document.tags.slice(0, 2).map((tag, i) => (
                  <span key={i} className="px-2 py-1 text-xs rounded-full bg-white/20 text-white backdrop-blur-sm">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
          
          <div className="p-6">
            <h3 className={`text-lg font-semibold mb-2 line-clamp-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {document.title}
            </h3>
            <p className={`text-sm mb-4 line-clamp-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {document.description}
            </p>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <span className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                  {document.size}
                </span>
                <span className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-400'} flex items-center`}>
                  <Download className="w-3 h-3 mr-1" />
                  {document.downloadCount}
                </span>
              </div>
              <span className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                {formatDate(document.uploadDate)}
              </span>
            </div>
          </div>
        </div>

        {/* Back Face */}
        <div className={`backface-hidden rotate-y-180 absolute inset-0 overflow-hidden rounded-3xl backdrop-blur-md border ${
          isDarkMode 
            ? 'bg-gray-800/60 border-gray-700/50' 
            : 'bg-white/80 border-white/30'
        } shadow-xl`}>
          <div className="p-6 h-full flex flex-col items-center justify-center text-center space-y-4">
            <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${typeColor} flex items-center justify-center animate-pulse`}>
              <FileIcon className="w-8 h-8 text-white" />
            </div>
            
            <h3 className={`text-lg font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {document.title}
            </h3>
            
            <div className="flex flex-wrap gap-1 justify-center">
              {document.tags.map((tag, i) => (
                <span key={i} className={`px-2 py-1 text-xs rounded-full ${
                  isDarkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-600'
                }`}>
                  #{tag}
                </span>
              ))}
            </div>
            
            <div className="flex space-x-2 mt-4">
              <button className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-medium transition-all duration-300 transform hover:scale-105 hover:shadow-lg">
                <Eye className="w-4 h-4 mr-2 inline" />
                Preview
              </button>
              <button className="px-4 py-2 rounded-xl bg-gradient-to-r from-green-500 to-teal-500 text-white text-sm font-medium transition-all duration-300 transform hover:scale-105 hover:shadow-lg">
                <Download className="w-4 h-4 mr-2 inline" />
                Download
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentCard;