import React from 'react';
import { Search, X } from 'lucide-react';

interface SearchBarProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isDarkMode: boolean;
}

const SearchBar: React.FC<SearchBarProps> = ({ searchQuery, setSearchQuery, isDarkMode }) => {
  return (
    <div className="relative max-w-2xl mx-auto">
      <div className={`relative overflow-hidden rounded-2xl backdrop-blur-md border transition-all duration-300 focus-within:scale-105 focus-within:shadow-2xl ${
        isDarkMode 
          ? 'bg-gray-800/60 border-gray-700/50 focus-within:border-purple-500/50' 
          : 'bg-white/80 border-white/30 focus-within:border-purple-500/50'
      }`}>
        <div className="flex items-center">
          <div className="pl-4">
            <Search className={`w-5 h-5 transition-colors duration-300 ${
              searchQuery ? 'text-purple-500' : isDarkMode ? 'text-gray-400' : 'text-gray-500'
            }`} />
          </div>
          <input
            type="text"
            placeholder="Search documents by title, description, or tags..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full px-4 py-4 bg-transparent border-none outline-none placeholder-gray-400 text-lg ${
              isDarkMode ? 'text-white' : 'text-gray-900'
            }`}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className={`mr-4 p-2 rounded-full transition-all duration-300 hover:scale-110 ${
                isDarkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
              }`}
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          )}
        </div>
        
        {/* Animated border */}
        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 transform scale-x-0 transition-transform duration-300 origin-left focus-within:scale-x-100"></div>
      </div>
      
      {/* Search suggestions */}
      {searchQuery && (
        <div className={`absolute top-full left-0 right-0 mt-2 rounded-xl backdrop-blur-md border overflow-hidden z-10 ${
          isDarkMode 
            ? 'bg-gray-800/90 border-gray-700/50' 
            : 'bg-white/90 border-white/30'
        }`}>
          <div className="p-2">
            {['proposal', 'design', 'finance', 'meeting'].filter(tag => 
              tag.toLowerCase().includes(searchQuery.toLowerCase())
            ).map((suggestion, index) => (
              <button
                key={index}
                onClick={() => setSearchQuery(suggestion)}
                className={`w-full text-left px-3 py-2 rounded-lg transition-colors duration-200 ${
                  isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-700'
                }`}
              >
                Search for "{suggestion}"
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchBar;