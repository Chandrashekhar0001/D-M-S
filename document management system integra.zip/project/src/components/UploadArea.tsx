import React, { useState, useRef } from 'react';
import { Upload, FileText, Image, Video, Music, X } from 'lucide-react';

interface UploadAreaProps {
  isDarkMode: boolean;
}

const UploadArea: React.FC<UploadAreaProps> = ({ isDarkMode }) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    handleFileUpload(files);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      handleFileUpload(files);
    }
  };

  const handleFileUpload = (files: File[]) => {
    setUploadedFiles(files);
    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          setTimeout(() => {
            setUploadedFiles([]);
            setUploadProgress(0);
          }, 2000);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) return Image;
    if (file.type.startsWith('video/')) return Video;
    if (file.type.startsWith('audio/')) return Music;
    return FileText;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="mb-8">
      <div
        className={`relative overflow-hidden rounded-3xl border-2 border-dashed transition-all duration-500 transform ${
          isDragOver
            ? 'border-purple-500 bg-purple-500/10 scale-105'
            : isDarkMode
            ? 'border-gray-600 bg-gray-800/30'
            : 'border-gray-300 bg-white/50'
        } backdrop-blur-md hover:scale-[1.02]`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          onChange={handleFileSelect}
          className="hidden"
          accept=".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg,.gif,.mp4,.mp3,.xlsx,.pptx"
        />
        
        <div className="p-8 text-center">
          {isUploading ? (
            <div className="space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-green-500 to-teal-500 rounded-full animate-spin">
                <Upload className="w-8 h-8 text-white" />
              </div>
              <h3 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Uploading Files...
              </h3>
              <div className={`w-full max-w-md mx-auto bg-gray-200 rounded-full h-2 ${isDarkMode ? 'bg-gray-700' : ''}`}>
                <div 
                  className="bg-gradient-to-r from-green-500 to-teal-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {uploadProgress}% Complete
              </p>
            </div>
          ) : uploadedFiles.length > 0 ? (
            <div className="space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-green-500 to-teal-500 rounded-full">
                <Upload className="w-8 h-8 text-white" />
              </div>
              <h3 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Upload Complete!
              </h3>
              <div className="space-y-2 max-w-md mx-auto">
                {uploadedFiles.map((file, index) => {
                  const FileIcon = getFileIcon(file);
                  return (
                    <div key={index} className={`flex items-center justify-between p-3 rounded-xl ${
                      isDarkMode ? 'bg-gray-700/50' : 'bg-white/70'
                    }`}>
                      <div className="flex items-center space-x-3">
                        <FileIcon className={`w-5 h-5 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`} />
                        <div className="text-left">
                          <p className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                            {file.name}
                          </p>
                          <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            {formatFileSize(file.size)}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full transition-all duration-300 ${
                isDragOver 
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 animate-bounce' 
                  : 'bg-gradient-to-r from-blue-500 to-purple-500'
              }`}>
                <Upload className={`w-8 h-8 text-white transition-transform duration-300 ${
                  isDragOver ? 'scale-110' : ''
                }`} />
              </div>
              <div>
                <h3 className={`text-xl font-semibold mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {isDragOver ? 'Drop files here!' : 'Upload Documents'}
                </h3>
                <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Drag and drop files here, or click to browse
                </p>
                <p className={`text-xs mt-2 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                  Supports PDF, DOC, Images, Videos, and more (Max 10MB per file)
                </p>
              </div>
              <button className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl font-medium transition-all duration-300 transform hover:scale-105 hover:shadow-lg">
                Choose Files
              </button>
            </div>
          )}
        </div>

        {/* Animated Background Elements */}
        <div className="absolute top-4 left-4 w-2 h-2 bg-purple-400 rounded-full animate-ping opacity-40"></div>
        <div className="absolute bottom-4 right-4 w-3 h-3 bg-pink-400 rounded-full animate-pulse opacity-40"></div>
        <div className="absolute top-1/2 right-8 w-1 h-1 bg-blue-400 rounded-full animate-bounce opacity-40"></div>
      </div>
    </div>
  );
};

export default UploadArea;