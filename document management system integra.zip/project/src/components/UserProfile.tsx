import React from 'react';
import { User, Mail, Calendar, Award } from 'lucide-react';

interface UserProfileProps {
  isDarkMode: boolean;
}

const UserProfile: React.FC<UserProfileProps> = ({ isDarkMode }) => {
  return (
    <div className={`p-6 rounded-2xl backdrop-blur-md border ${
      isDarkMode 
        ? 'bg-gray-800/60 border-gray-700/50' 
        : 'bg-white/80 border-white/30'
    }`}>
      <div className="flex items-center space-x-4 mb-6">
        <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
          <User className="w-8 h-8 text-white" />
        </div>
        <div>
          <h3 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            John Doe
          </h3>
          <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            Document Administrator
          </p>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex items-center space-x-3">
          <Mail className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
          <span className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
            john.doe@company.com
          </span>
        </div>
        
        <div className="flex items-center space-x-3">
          <Calendar className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
          <span className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
            Joined December 2023
          </span>
        </div>
        
        <div className="flex items-center space-x-3">
          <Award className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
          <span className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
            245 Documents Uploaded
          </span>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;